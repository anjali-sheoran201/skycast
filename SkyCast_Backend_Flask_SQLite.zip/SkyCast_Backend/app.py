from flask import Flask, request, jsonify
from flask_cors import CORS
from database import init_db, save_profile, get_profile, save_advisory, get_history

app = Flask(__name__)
CORS(app)  # Allows a separately hosted frontend to call this API.
init_db()

@app.get("/")
def home():
    return jsonify({
        "project": "SkyCast Backend API",
        "status": "running",
        "endpoints": [
            "GET /api/health",
            "GET|POST /api/profile",
            "GET /api/history",
            "POST /api/advisory"
        ]
    })

@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "message": "SkyCast API is working"})

@app.route("/api/profile", methods=["GET", "POST"])
def profile():
    if request.method == "GET":
        return jsonify(get_profile())

    data = request.get_json(silent=True) or {}
    required = ["farmer_name", "city"]
    missing = [key for key in required if not str(data.get(key, "")).strip()]
    if missing:
        return jsonify({"error": "Missing required fields", "fields": missing}), 400

    save_profile(data)
    return jsonify({"message": "Farmer profile saved successfully"})

@app.get("/api/history")
def history():
    return jsonify(get_history())

@app.post("/api/advisory")
def advisory():
    data = request.get_json(silent=True) or {}
    city = str(data.get("city", "")).strip()
    message = str(data.get("message", "")).strip()
    recommendation = str(data.get("recommendation", "")).strip()

    if not city or not message:
        return jsonify({"error": "city and message are required"}), 400

    save_advisory(city, message, recommendation)
    return jsonify({"message": "Advisory saved successfully"}), 201

if __name__ == "__main__":
    app.run(debug=True)
