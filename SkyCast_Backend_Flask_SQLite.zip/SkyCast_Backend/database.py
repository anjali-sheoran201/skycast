import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).with_name("skycast.db")

def get_connection():
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection

def init_db():
    with get_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS farmer_profiles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                farmer_name TEXT NOT NULL,
                city TEXT NOT NULL,
                farm_size REAL DEFAULT 0,
                soil_type TEXT DEFAULT '',
                preferred_crop TEXT DEFAULT '',
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS advisory_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                city TEXT NOT NULL,
                message TEXT NOT NULL,
                recommendation TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)

def save_profile(data):
    with get_connection() as conn:
        existing = conn.execute(
            "SELECT id FROM farmer_profiles ORDER BY id DESC LIMIT 1"
        ).fetchone()

        values = (
            str(data.get("farmer_name", "")).strip(),
            str(data.get("city", "")).strip(),
            float(data.get("farm_size") or 0),
            str(data.get("soil_type", "")).strip(),
            str(data.get("preferred_crop", "")).strip()
        )

        if existing:
            conn.execute("""
                UPDATE farmer_profiles
                SET farmer_name=?, city=?, farm_size=?, soil_type=?,
                    preferred_crop=?, updated_at=CURRENT_TIMESTAMP
                WHERE id=?
            """, (*values, existing["id"]))
        else:
            conn.execute("""
                INSERT INTO farmer_profiles
                (farmer_name, city, farm_size, soil_type, preferred_crop)
                VALUES (?, ?, ?, ?, ?)
            """, values)

def get_profile():
    with get_connection() as conn:
        row = conn.execute(
            "SELECT * FROM farmer_profiles ORDER BY id DESC LIMIT 1"
        ).fetchone()
        return dict(row) if row else {}

def save_advisory(city, message, recommendation):
    with get_connection() as conn:
        conn.execute("""
            INSERT INTO advisory_history (city, message, recommendation)
            VALUES (?, ?, ?)
        """, (city, message, recommendation))

def get_history():
    with get_connection() as conn:
        rows = conn.execute("""
            SELECT id, city, message, recommendation, created_at
            FROM advisory_history
            ORDER BY id DESC
        """).fetchall()
        return [dict(row) for row in rows]
