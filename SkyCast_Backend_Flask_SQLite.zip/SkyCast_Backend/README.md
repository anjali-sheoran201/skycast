# SkyCast – Backend (Flask + SQLite)

This folder contains the backend API for **SkyCast – Smart Weather & Agriculture Advisory System**.

## Technologies
- Python
- Flask
- SQLite
- Flask-CORS

## Features
- Flask REST API
- Farmer profile storage in SQLite
- Agriculture advisory history storage
- JSON responses for frontend integration

## Project Structure

```text
SkyCast_Backend/
├── app.py
├── database.py
├── requirements.txt
├── README.md
└── skycast.db   # Created automatically when the app runs
```

## Setup and Run

### 1. Install Python
Install Python 3.10 or newer.

### 2. Open this folder in VS Code

Open a terminal in the `SkyCast_Backend` folder.

### 3. Create a virtual environment

```bash
python -m venv venv
```

### 4. Activate it on Windows

```bash
venv\\Scripts\\activate
```

### 5. Install dependencies

```bash
python -m pip install -r requirements.txt
```

### 6. Start the server

```bash
python app.py
```

Open this address in your browser:

```text
http://127.0.0.1:5000
```

## API Endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Check API status |
| GET | `/api/profile` | Get saved farmer profile |
| POST | `/api/profile` | Create or update farmer profile |
| GET | `/api/history` | Get advisory history |
| POST | `/api/advisory` | Save an advisory entry |

### Example: Save a farmer profile

Send a `POST` request to `/api/profile` with JSON:

```json
{
  "farmer_name": "Demo Farmer",
  "city": "Palwal",
  "farm_size": 2.5,
  "soil_type": "Alluvial",
  "preferred_crop": "Wheat"
}
```

### Example: Save an advisory

Send a `POST` request to `/api/advisory` with JSON:

```json
{
  "city": "Palwal",
  "message": "Check the local forecast before irrigation.",
  "recommendation": "Plan irrigation according to soil moisture and local conditions."
}
```

## Database

SQLite database file `skycast.db` is created automatically in this folder when the application starts.

## Important Notes

- This is a backend starter/API package. The standalone `SkyCast_Frontend_One_File.html` currently uses browser Local Storage for its profile and history features.
- The frontend does **not** automatically connect to this backend yet. JavaScript API integration is a separate step.
- Weather data in the frontend is fetched directly from Open-Meteo.
- Crop suggestions and chatbot responses in the current frontend are rule-based demonstrations, not trained machine-learning models.
- Do not upload your virtual environment (`venv/`) or Python cache (`__pycache__/`) to GitHub.

## Future Enhancements
- Connect the frontend forms to these API endpoints.
- Add authentication and user-specific profiles.
- Add validated, region-specific agricultural datasets.
- Integrate a trained crop recommendation model.
